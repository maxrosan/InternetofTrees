<?php
 $con = mysqli_connect('localhost','root','bresil','donnees');
?>
